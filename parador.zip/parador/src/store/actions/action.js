// src/store/actions/action.js
import {
  ADD_TO_CART,
  DECREMENT_QUANTITY,
  INCREMENT_QUANTITY,
  REMOVE_FROM_CART,
  LOAD_USER_CART,
  CLEAR_CART,
} from "./type";
import { cartService } from '../../api/cartService';
import { toast } from 'react-toastify';

// ============================================
// 🔥 CARGAR CARRITO DESDE BACKEND
// ============================================
export const loadUserCart = (userId) => async (dispatch) => {
  try {
    // Si no hay userId, limpiar carrito (logout)
    if (!userId) {
      console.log('🚪 No hay usuario - Limpiando carrito');
      dispatch({
        type: LOAD_USER_CART,
        payload: null,
        cart: []
      });
      return;
    }

    console.log('🔄 Cargando carrito desde backend para:', userId);

    // Llamar al backend para obtener el carrito
    const response = await cartService.getCart();

    if (response.success && response.data.items) {
      // Transformar datos del backend al formato de Redux
      const cartItems = response.data.items.map(item => ({
        id: item.cart_item_id,
        room_id: item.room_id,
        room_number: item.room_number,
        title: item.room_type,
        capacity: item.adults,
        qty: item.nights,
        price: Math.round(item.price_total / item.nights), // Precio por noche
        check_in: item.check_in,
        check_out: item.check_out,
        adults: item.adults,
        totalPrice: item.price_total,
        discount: 0,
        sum: item.price_total
      }));

      console.log(`✅ Carrito cargado desde BACKEND: ${cartItems.length} items`);

      // Despachar acción para cargar en Redux
      dispatch({
        type: LOAD_USER_CART,
        payload: userId,
        cart: cartItems
      });

    } else {
      console.warn('⚠️ Respuesta del backend sin items');
      // Carrito vacío
      dispatch({
        type: LOAD_USER_CART,
        payload: userId,
        cart: []
      });
    }
  } catch (error) {
    console.error('❌ Error al cargar carrito desde backend:', error);

    // Si falla, cargar carrito vacío
    dispatch({
      type: LOAD_USER_CART,
      payload: userId,
      cart: []
    });
  }
};

// ============================================
// 🔥 AGREGAR AL CARRITO (Backend + Redux)
// ============================================
export const addToCart = (product, qty, color, size, roomData) => async (dispatch, getState) => {
  try {
    // Si roomData está presente, usar el backend
    if (roomData) {
      console.log('🛒 Agregando al carrito (Backend):', roomData);

      const response = await cartService.addToCart({
        room_id: product.id,
        check_in: roomData.check_in,
        check_out: roomData.check_out,
        adults: roomData.adults || 1,
        children: roomData.children || 0
      });

      if (response.success) {
        toast.success('Habitación agregada al carrito');

        // Recargar carrito desde backend
        const state = getState();
        const userId = state.cartList.currentUserId;

        if (userId) {
          await dispatch(loadUserCart(userId));
        }
      }
    } else {
      // Agregar solo localmente (para productos que no son habitaciones)
      console.log('🛒 Agregando al carrito (Local):', product.title);

      dispatch({
        type: ADD_TO_CART,
        product,
        qty: qty ? qty : 1,
        color: color ? color : "",
        size: size ? size : ""
      });

      toast.success('Producto agregado al carrito');
    }
  } catch (error) {
    const message = error.response?.data?.message || 'Error al agregar al carrito';
    console.error('❌ Error:', error);
    toast.error(message);
  }
};

// ============================================
// 🔥 REMOVER DEL CARRITO (Backend + Redux)
// ============================================
export const removeFromCart = (cartItemId) => async (dispatch, getState) => {
  try {
    console.log('🗑️ Eliminando del carrito:', cartItemId);

    // Intentar eliminar del backend
    const response = await cartService.removeFromCart(cartItemId);

    if (response.success) {
      toast.success('Habitación eliminada del carrito');

      // Eliminar también de Redux
      dispatch({
        type: REMOVE_FROM_CART,
        product_id: cartItemId
      });
    }
  } catch (error) {
    console.error('❌ Error al eliminar:', error);
    toast.error('Error al eliminar del carrito');
  }
};

// ============================================
// 🔥 INCREMENTAR CANTIDAD (Solo Local)
// ============================================
export const incrementQuantity = (product_id) => (dispatch) => {
  console.log('➕ Incrementando cantidad (local):', product_id);

  dispatch({
    type: INCREMENT_QUANTITY,
    product_id
  });
};

// ============================================
// 🔥 DECREMENTAR CANTIDAD (Solo Local)
// ============================================
export const decrementQuantity = (product_id) => (dispatch) => {
  console.log('➖ Decrementando cantidad (local):', product_id);

  dispatch({
    type: DECREMENT_QUANTITY,
    product_id
  });
};

// ============================================
// 🔥 LIMPIAR CARRITO (Backend + Redux)
// ============================================
export const clearCart = () => async (dispatch) => {
  try {
    console.log('🧹 Limpiando carrito...');

    const response = await cartService.clearCart();

    if (response.success) {
      toast.success('Carrito vaciado');

      dispatch({
        type: CLEAR_CART
      });
    }
  } catch (error) {
    console.error('❌ Error al limpiar carrito:', error);

    // Limpiar localmente aunque falle el backend
    dispatch({
      type: CLEAR_CART
    });

    toast.warning('Carrito limpiado localmente');
  }
};