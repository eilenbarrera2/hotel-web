// src/store/reducers/cart.js
import {
  ADD_TO_CART,
  DECREMENT_QUANTITY,
  INCREMENT_QUANTITY,
  REMOVE_FROM_CART,
  LOAD_USER_CART,
  CLEAR_CART,
} from "../actions/type";
import { minValueOne } from "../../utils";

// ============================================
// ESTADO INICIAL (SIN LOCALSTORAGE)
// ============================================
const init = {
  cart: [],              // Carrito del usuario actual
  currentUserId: null,   // ID del usuario actual
  isLoading: false,      // Estado de carga
};

// ============================================
// REDUCER
// ============================================
export const cartReducer = (state = init, action) => {
  let currentCart;

  switch (action.type) {

    // ==========================================
    // 🔥 CARGAR CARRITO (desde Backend)
    // ==========================================
    case LOAD_USER_CART:
      const userId = action.payload;

      // Si no hay userId (logout), limpiar carrito
      if (!userId) {
        console.log('🚪 Sesión cerrada - Carrito limpiado');
        return {
          ...state,
          currentUserId: null,
          cart: [],
          isLoading: false
        };
      }

      // Cargar carrito desde el backend
      const backendCart = action.cart || [];
      console.log(`✅ Reducer: Carrito cargado para ${userId} - ${backendCart.length} items`);

      return {
        ...state,
        currentUserId: userId,
        cart: backendCart,
        isLoading: false
      };

    // ==========================================
    // AGREGAR AL CARRITO (Local solo)
    // ==========================================
    case ADD_TO_CART:
      const productId = action.product.id;
      const productQty = action.qty ? action.qty : 1;

      if (state.cart.findIndex((product) => product.id === productId) !== -1) {
        // Si el producto ya existe, incrementar cantidad
        currentCart = state.cart.reduce((cartAcc, product) => {
          if (product.id === productId) {
            cartAcc.push({
              ...product,
              selected_color: action.color,
              selected_size: action.size,
              qty: product.qty + productQty,
              sum:
                ((product.price * (100 - product.discount)) / 100) *
                (product.qty + productQty),
            });
          } else {
            cartAcc.push(product);
          }
          return cartAcc;
        }, []);
      } else {
        // Si el producto no existe, agregarlo
        currentCart = [
          ...state.cart,
          {
            ...action.product,
            selected_color: action.color,
            selected_size: action.size,
            qty: productQty,
            sum:
              ((action.product.price * (100 - action.product.discount)) / 100) *
              productQty,
          },
        ];
      }

      console.log('🛒 Producto agregado localmente:', action.product.title);

      return {
        ...state,
        cart: currentCart,
      };

    // ==========================================
    // REMOVER DEL CARRITO
    // ==========================================
    case REMOVE_FROM_CART:
      currentCart = state.cart.filter((item) => item.id !== action.product_id);

      console.log('🗑️ Producto removido del carrito');

      return {
        ...state,
        cart: currentCart,
      };

    // ==========================================
    // INCREMENTAR CANTIDAD
    // ==========================================
    case INCREMENT_QUANTITY:
      const inc_productId = action.product_id;
      currentCart = state.cart.reduce((cartAcc, product) => {
        if (product.id === inc_productId) {
          cartAcc.push({
            ...product,
            qty: product.qty + 1,
          });
        } else {
          cartAcc.push(product);
        }
        return cartAcc;
      }, []);

      console.log('➕ Cantidad incrementada');

      return {
        ...state,
        cart: currentCart,
      };

    // ==========================================
    // DECREMENTAR CANTIDAD
    // ==========================================
    case DECREMENT_QUANTITY:
      const decProductId = action.product_id;
      currentCart = state.cart.reduce((cartAcc, product) => {
        if (product.id === decProductId) {
          cartAcc.push({
            ...product,
            qty: minValueOne(product.qty - 1),
          });
        } else {
          cartAcc.push(product);
        }
        return cartAcc;
      }, []);

      console.log('➖ Cantidad decrementada');

      return {
        ...state,
        cart: currentCart,
      };

    // ==========================================
    // 🔥 LIMPIAR CARRITO
    // ==========================================
    case CLEAR_CART:
      console.log('🧹 Carrito limpiado completamente');

      return {
        ...state,
        cart: [],
      };

    default:
      return state;
  }
};

export default cartReducer;