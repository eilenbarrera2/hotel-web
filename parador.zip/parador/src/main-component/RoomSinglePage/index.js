import React, { Fragment, useEffect, useState } from 'react';
import PageTitle from '../../components/pagetitle/PageTitle';
import { useParams } from 'react-router-dom'
import Navbar from '../../components/Navbar';
import Scrollbar from '../../components/scrollbar'
import { connect } from "react-redux";
import api from "../../api";
import Footer from '../../components/footer';
import Logo from '../../images/logo2.png'
import Rooms from './rooms';
import RoomDetails from './RoomDetails';


const RoomSinglePage = (props) => {
    const { id } = useParams()


    const productsArray = api();
    const Allproduct = productsArray

    const [product, setProduct] = useState({});

    useEffect(() => {
        setProduct(Allproduct.filter(Allproduct => Allproduct.id === Number(id)))
    }, []);

    const item = product[0];

    return (
        <Fragment>
            <Navbar hclass={'wpo-header-style-3'} Logo={Logo} />
            <PageTitle pageTitle={item ? item.title : null} pagesub={'Habitación'} />
            <div className="room-details-section">
                {item ?
                    <div className="room-details-inner">
                        <div className="wpo-hotel-details-section">
                            <div className="container">
                                <div className="row">
                                    <div className="col-lg-12">
                                        <div className="wpo-hotel-details-wrap">
                                            <div className="wpo-hotel-details-area">
                                                <form className="clearfix">
                                                    <div className="details-sub">
                                                        <span>CAMAS</span>
                                                        <h2>{item.bedroom} Camas </h2>
                                                    </div>
                                                    <div className="details-sub">
                                                        <span>TAMAÑO DE HABITACIÓN</span>
                                                        <h2>870 pies² / {item.sqm} m²</h2>
                                                    </div>
                                                    <div className="details-sub">
                                                        <span>OCUPACIÓN</span>
                                                        <h2>{item.capacity} adultos ({item.Children} niños)</h2>
                                                    </div>
                                                    <div className="details-sub">
                                                        <span>Baño</span>
                                                        <h2>{item.bathroom} Ducha con bañera</h2>
                                                    </div>
                                                    <div className="details-sub">
                                                        <h5>Costo <span>${item.price}</span> /Noche</h5>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <Rooms item={item} />
                        <RoomDetails />
                    </div>
                    : null}
            </div>
            <Footer />
            <Scrollbar />
        </Fragment>
    )
};

const mapStateToProps = state => {
    return {
        products: state.data.products,
    }
};

export default connect(mapStateToProps)(RoomSinglePage);