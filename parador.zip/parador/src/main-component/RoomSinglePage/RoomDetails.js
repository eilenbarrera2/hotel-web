import React from 'react'
import { Link } from 'react-router-dom'
import simg1 from '../../images/room/img-7.jpg'
import simg2 from '../../images/room/img-8.jpg'

import rv1 from '../../images/room/r1.jpg'
import rv2 from '../../images/room/r2.jpg'
import RoomSidebar from './RoomSidebar'

const RoomDetails = (props) => {

    const SubmitHandler = (e) => {
        e.preventDefault()
    }

    const ClickHandler = () => {
        window.scrollTo(10, 0);
    }

    return (
        <div className="Room-details-area pb-120">
            <div className="container">
                <div className="row">
                    <div className="col-lg-8 col-12">
                        <div className="room-description">
                            <div className="room-title">
                                <h2>Descripción</h2>
                            </div>
                            <p className="p-wrap">Es difícil encontrar ejemplos de lorem ipsum en uso antes de que Letraset lo popularizara como texto de relleno en los años 60, aunque McClintock dice recordar haber encontrado el pasaje de lorem ipsum en un libro de muestras de tipos de metal antiguos.</p>
                            <p>Entonces, ¿cuándo está bien usar lorem ipsum? Primero, lorem ipsum funciona bien para maquetación. Es como los accesorios en una tienda de muebles: el texto de relleno hace que parezca que alguien está en casa. La misma plantilla de Wordpress eventualmente podría albergar un blog de fitness, un sitio web de fotografía o el diario en línea de un fanático de los cupcakes. Lorem ipsum les ayuda a imaginar cómo se vería el sitio web habitado.</p>
                            <p>En segundo lugar, use lorem ipsum si cree que el texto de marcador de posición será demasiado distractivo. Para proyectos específicos, la colaboración entre redactores y diseñadores puede ser lo mejor, sin embargo, como dijo Karen McGrane, el texto provisional tiene una forma de convertir cualquier reunión sobre decisiones de diseño en una discusión sobre la elección de palabras. Así que no temas usar lorem ipsum para mantener a todos enfocados.</p>
                        </div>
                        <div className="room-details-service">
                            <div className="row">
                                <div className="room-details-item">
                                    <div className="row">
                                        <div className="col-md-5 col-sm-5">
                                            <div className="room-d-text">
                                                <div className="room-title">
                                                    <h2>Comodidades</h2>
                                                </div>
                                                <ul>
                                                    <li><Link onClick={ClickHandler} to="/room-single/1">Refrigerador y agua</Link></li>
                                                    <li><Link onClick={ClickHandler} to="/room-single/1">Aire acondicionado</Link></li>
                                                    <li><Link onClick={ClickHandler} to="/room-single/1">Frutas siempre disponibles</Link></li>
                                                    <li><Link onClick={ClickHandler} to="/room-single/1">2 conjuntos de pijama</Link></li>
                                                    <li><Link onClick={ClickHandler} to="/room-single/1">Mesas y sillas</Link></li>
                                                    <li><Link onClick={ClickHandler} to="/room-single/1">2 ascensores disponibles</Link></li>
                                                    <li><Link onClick={ClickHandler} to="/room-single/1">Balcón lateral de la habitación</Link></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div className="col-md-7 col-sm-7">
                                            <div className="room-d-img">
                                                <img src={simg1} alt="" />
                                            </div>
                                        </div>
                                        <div className="col-md-7 col-sm-7">
                                            <div className="room-d-img">
                                                <img src={simg2} alt="" />
                                            </div>
                                        </div>
                                        <div className="col-md-5 col-sm-5">
                                            <div className="room-d-text2">
                                                <div className="room-title">
                                                    <h2>Servicios de la habitación</h2>
                                                </div>
                                                <ul>
                                                    <li><Link onClick={ClickHandler} to="/room-single/1">Limpieza diaria</Link></li>
                                                    <li><Link onClick={ClickHandler} to="/room-single/1">Piscina especial</Link></li>
                                                    <li><Link onClick={ClickHandler} to="/room-single/1">Estacionamiento gratuito</Link></li>
                                                    <li><Link onClick={ClickHandler} to="/room-single/1">Teléfono inteligente de uso gratuito</Link></li>
                                                    <li><Link onClick={ClickHandler} to="/room-single/1">Wifi gratis</Link></li>
                                                    <li><Link onClick={ClickHandler} to="/room-single/1">2 ascensores disponibles</Link></li>
                                                    <li><Link onClick={ClickHandler} to="/room-single/1">Balcón lateral de la habitación</Link></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="pricing-area">
                            <div className="room-title">
                                <h2>Planes de precios</h2>
                            </div>
                            <div className="pricing-table">
                                <table className="table-responsive pricing-wrap">
                                    <thead>
                                        <tr>
                                            <th>Lun</th>
                                            <th>Mar</th>
                                            <th>Mié</th>
                                            <th>Jue</th>
                                            <th>Vie</th>
                                            <th>Sáb</th>
                                            <th>Dom</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>$250</td>
                                            <td>$250</td>
                                            <td>$250</td>
                                            <td>$250</td>
                                            <td>$250</td>
                                            <td>$250</td>
                                            <td>$250</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>

                            <div className="map-area">
                                <iframe
                                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d4740.772574523826!2d-99.19968508829167!3d20.460919480971114!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x85d3dffb946d06a7%3A0x6be0b90a9394d3ef!2sHotel%20Dios%20Padre!5e1!3m2!1ses-419!2smx!4v1759346866440!5m2!1ses-419!2smx"></iframe>
                            </div>
                        </div>
                        <div className="room-review">
                            <div className="room-title">
                                <h2>Reseñas de la habitación</h2>
                            </div>
                            <div className="review-item">
                                <div className="review-img">
                                    <img src={rv1} alt="" />
                                </div>
                                <div className="review-text">
                                    <div className="r-title">
                                        <h2>Marry Watson</h2>
                                        <ul>
                                            <li><i className="fa fa-star" aria-hidden="true"></i></li>
                                            <li><i className="fa fa-star" aria-hidden="true"></i></li>
                                            <li><i className="fa fa-star" aria-hidden="true"></i></li>
                                            <li><i className="fa fa-star" aria-hidden="true"></i></li>
                                            <li><i className="fa fa-star" aria-hidden="true"></i></li>
                                        </ul>
                                    </div>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis.</p>
                                </div>
                            </div>
                            <div className="review-item">
                                <div className="review-img">
                                    <img src={rv2} alt="" />
                                </div>
                                <div className="review-text">
                                    <div className="r-title">
                                        <h2>Lily Havenly</h2>
                                        <ul>
                                            <li><i className="fa fa-star" aria-hidden="true"></i></li>
                                            <li><i className="fa fa-star" aria-hidden="true"></i></li>
                                            <li><i className="fa fa-star" aria-hidden="true"></i></li>
                                            <li><i className="fa fa-star" aria-hidden="true"></i></li>
                                            <li><i className="fa fa-star" aria-hidden="true"></i></li>
                                        </ul>
                                    </div>
                                    <p>Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis.</p>
                                </div>
                            </div>
                        </div>
                        <div className="add-review">
                            <div className="room-title">
                                <h2>Agregar reseña</h2>
                            </div>
                            <div className="wpo-blog-single-section review-form ">
                                <div className="give-rat-sec">
                                    <p>Tu calificación *</p>
                                    <div className="give-rating">
                                        <label>
                                            <input type="radio" name="stars" value="1" />
                                            <span className="icon">★</span>
                                        </label>
                                        <label>
                                            <input type="radio" name="stars" value="2" />
                                            <span className="icon">★</span>
                                            <span className="icon">★</span>
                                        </label>
                                        <label>
                                            <input type="radio" name="stars" value="3" />
                                            <span className="icon">★</span>
                                            <span className="icon">★</span>
                                            <span className="icon">★</span>
                                        </label>
                                        <label>
                                            <input type="radio" name="stars" value="4" />
                                            <span className="icon">★</span>
                                            <span className="icon">★</span>
                                            <span className="icon">★</span>
                                            <span className="icon">★</span>
                                        </label>
                                        <label>
                                            <input type="radio" name="stars" value="5" />
                                            <span className="icon">★</span>
                                            <span className="icon">★</span>
                                            <span className="icon">★</span>
                                            <span className="icon">★</span>
                                            <span className="icon">★</span>
                                        </label>
                                    </div>
                                </div>
                                <div className="review-add">
                                    <div className="comment-respond">
                                        <form id="commentform" className="comment-form" onSubmit={SubmitHandler}>
                                            <div className="form-inputs">
                                                <input placeholder="Tu nombre*" type="text" />
                                                <input placeholder="Tu email*" type="email" />
                                            </div>
                                            <div className="form-textarea">
                                                <textarea id="comment" placeholder="Tu reseña"></textarea>
                                            </div>
                                            <div className="form-check">
                                                <div className="shipp pb">
                                                    <input type="checkbox" id="c2" name="cc" />
                                                    <label htmlFor="c2"><span></span>Guardar mi nombre, email y sitio web en este navegador para la próxima vez que comente.</label>
                                                </div>
                                            </div>
                                            <div className="form-submit">
                                                <input id="submit" value="Enviar ahora" type="submit" />
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <RoomSidebar />
                </div>
            </div>
        </div>
    )
}

export default RoomDetails;